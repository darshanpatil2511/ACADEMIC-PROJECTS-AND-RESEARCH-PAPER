import React, { useState } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, CardElement, useStripe, useElements } from "@stripe/react-stripe-js";
import "../styles/Payment.css";
import Footer from "../components/Footer";

// Load the Stripe public key
const stripePromise = loadStripe("pk_test_51QTBVGI5UZdhvvotjNuXybYednO5aWbGXGdf3bPaOpqfJDn4A7ZBP3Rab9xotAqDWJ5qGjDsJcfuXrVLG1cPN88z00fXigZv5d");

const CheckoutForm = () => {
  const stripe = useStripe();
  const elements = useElements();

  const [cardholderName, setCardholderName] = useState("");
  const [email, setEmail] = useState("");
  const [billingAddress, setBillingAddress] = useState("");
  const [membershipType, setMembershipType] = useState("basic");
  const [error, setError] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [succeeded, setSucceeded] = useState(false);

  const membershipOptions = {
    basic: { name: "Basic Membership", price: 1000 }, // $10.00
    premium: { name: "Premium Membership", price: 2500 }, // $25.00
    elite: { name: "Elite Membership", price: 5000 }, // $50.00
  };

  const paymentAmount = membershipOptions[membershipType].price;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setProcessing(true);
    setError(null);

    try {
      const response = await fetch("http://localhost:5009/api/payments/create-payment-intent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: paymentAmount, currency: "usd" }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Server error");
      }

      const { clientSecret } = await response.json();

      const { error } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement),
          billing_details: {
            name: cardholderName,
            email: email,
            address: { line1: billingAddress },
          },
        },
      });

      if (error) {
        setError(error.message);
        return;
      }

      setSucceeded(true);
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="payment-container">
      <h2 className="payment-header">Complete Your Membership Payment</h2>
      <p className="text-center text-muted mb-4">
        Select your membership and complete the payment to enjoy exclusive benefits.
      </p>

      <form className="payment-form" onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="membershipType" className="form-label">
            Select Membership Type
          </label>
          <select
            className="form-control"
            id="membershipType"
            value={membershipType}
            onChange={(e) => setMembershipType(e.target.value)}
          >
            <option value="basic">Basic Membership - $10.00</option>
            <option value="premium">Premium Membership - $25.00</option>
            <option value="elite">Elite Membership - $50.00</option>
          </select>
        </div>

        <div className="mb-3">
          <label htmlFor="cardholderName" className="form-label">
            Cardholder's Name
          </label>
          <input
            type="text"
            className="form-control"
            id="cardholderName"
            value={cardholderName}
            onChange={(e) => setCardholderName(e.target.value)}
            placeholder="Full Name"
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="email" className="form-label">
            Email Address
          </label>
          <input
            type="email"
            className="form-control"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email for confirmation"
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="billingAddress" className="form-label">
            Billing Address
          </label>
          <input
            type="text"
            className="form-control"
            id="billingAddress"
            value={billingAddress}
            onChange={(e) => setBillingAddress(e.target.value)}
            placeholder="Street Address, City, State, ZIP Code"
            required
          />
        </div>

        <div className="mb-4">
          <label className="form-label">Card Details</label>
          <CardElement className="form-control p-3 card-element" />
        </div>

        <button
          type="submit"
          className="btn btn-primary btn-block"
          disabled={!stripe || processing || succeeded}
        >
          {processing ? (
            <span
              className="spinner-border spinner-border-sm"
              role="status"
              aria-hidden="true"
            ></span>
          ) : (
            `Pay $${(paymentAmount / 100).toFixed(2)}`
          )}
        </button>

        {error && <div className="alert alert-danger mt-3">{error}</div>}
        {succeeded && (
          <div className="alert alert-success mt-3">
            Payment succeeded! Thank you for your support.
          </div>
        )}
      </form>
    </div>
  );
};

const Payment = () => (
  <div className="payment-page">
    <div className="container py-5 d-flex justify-content-center align-items-center">
      <Elements stripe={stripePromise}>
        <CheckoutForm />
      </Elements>
    </div>
    <Footer />
  </div>
);

export default Payment;
