import React, { useState } from "react";
import "../styles/Contact.css";
import Footer from "../components/Footer";

function Contact() {
  const [showPopup, setShowPopup] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    // Prepare form data for backend
    const contactData = {
      name: formData.get("name"),
      email: formData.get("email"),
      subject: formData.get("subject"),
      message: formData.get("message"),
    };

    try {
      const response = await fetch("http://localhost:5009/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(contactData),
      });

      if (!response.ok) {
        throw new Error("Failed to send message. Please try again later.");
      }

      // Show the success popup upon submission
      setShowPopup(true);

      // Reset the form fields
      e.target.reset();
    } catch (error) {
      alert(error.message);
    }
  };

  const closePopup = () => {
    setShowPopup(false);
  };

  return (
    <div
      className="contact-page"
      style={{
        background: "linear-gradient(to right, #f7f8fa, #e3f2fd)",
        minHeight: "100vh",
        paddingTop: "20px",
      }}
    >
      <section className="contact py-5">
        <div className="container">
          <h2 className="text-center text-primary mb-4">Stay Connected with CareLink</h2>
          <p className="text-center text-muted mb-5">
            "Every connection matters. Whether you're seeking assistance, ready
            to make a difference, or just want to say hello, we’re here to
            listen and support."
          </p>

          <div className="row">
            {/* Contact Form */}
            <div className="col-lg-6 mb-4">
              <div className="card shadow rounded">
                <div className="card-body">
                  <h5 className="card-title text-center">Send Us a Message</h5>
                  <p className="text-center text-muted">
                    Your questions and feedback help us grow. Fill out the form
                    below, and we'll get back to you as soon as possible.
                  </p>
                  <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                      <label htmlFor="name" className="form-label">
                        Name
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="name"
                        name="name"
                        placeholder="Your Full Name"
                        required
                      />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="email" className="form-label">
                        Email
                      </label>
                      <input
                        type="email"
                        className="form-control"
                        id="email"
                        name="email"
                        placeholder="Your Email Address"
                        required
                      />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="subject" className="form-label">
                        Subject
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="subject"
                        name="subject"
                        placeholder="Subject"
                        required
                      />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="message" className="form-label">
                        Message
                      </label>
                      <textarea
                        className="form-control"
                        id="message"
                        name="message"
                        rows="5"
                        placeholder="Write your message here..."
                        required
                      ></textarea>
                    </div>
                    <div className="d-grid">
                      <button type="submit" className="btn btn-primary">
                        Submit
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div className="col-lg-6">
              <div className="info-card bg-white rounded shadow p-4">
                <h5 className="text-primary">Contact Information</h5>
                <p className="text-muted">
                  "We’re here to help. Reach out to us via phone, email, or visit
                  us in person. Let's make great things happen together!"
                </p>
                <p>
                  <strong>Phone:</strong> +1 (123) 456-7890
                </p>
                <p>
                  <strong>Email:</strong> contact@carelinkconnect.com
                </p>
                <p>
                  <strong>Address:</strong> 123 CareLink Lane, Community City,
                  USA
                </p>
                <hr />
                <h5 className="text-primary">Follow Us</h5>
                <p className="text-muted">
                  Stay connected with us on social media for updates and
                  inspiration.
                </p>
                <div className="d-flex">
                  <a
                    href="#"
                    className="btn btn-outline-primary btn-sm me-2"
                    aria-label="Facebook"
                  >
                    <i className="bi bi-facebook"></i>
                  </a>
                  <a
                    href="#"
                    className="btn btn-outline-primary btn-sm me-2"
                    aria-label="Twitter"
                  >
                    <i className="bi bi-twitter"></i>
                  </a>
                  <a
                    href="#"
                    className="btn btn-outline-primary btn-sm"
                    aria-label="Instagram"
                  >
                    <i className="bi bi-instagram"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Popup Modal */}
      {showPopup && (
        <div className="popup-overlay">
          <div className="popup-content">
            <h5>Your message has been submitted successfully!</h5>
            <button className="btn btn-primary mt-3" onClick={closePopup}>
              Close
            </button>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}

export default Contact;
