// src/pages/VolunteerDashboard.js
import React, { useState, useEffect } from "react";
import "../styles/VolunteerDashboard.css";
import Footer from "../components/Footer";

function VolunteerDashboard() {
  const [requests, setRequests] = useState([]);
  const [acceptedRequests, setAcceptedRequests] = useState([]);

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        const response = await fetch("http://localhost:5009/api/requests");
        if (!response.ok) {
          throw new Error("Failed to fetch requests.");
        }
        const data = await response.json();
        setRequests(data);
      } catch (err) {
        console.error("Error fetching requests:", err);
      }
    };

    const fetchAcceptedRequests = async () => {
      try {
        const response = await fetch("http://localhost:5009/api/requests/accepted");
        if (!response.ok) {
          throw new Error("Failed to fetch accepted requests.");
        }
        const data = await response.json();
        setAcceptedRequests(data);
      } catch (err) {
        console.error("Error fetching accepted requests:", err);
      }
    };

    fetchRequests();
    fetchAcceptedRequests();
  }, []);

  const handleAccept = async (requestId) => {
    try {
      const response = await fetch(
        `http://localhost:9/api/requests/${requestId}/accept`,
        { method: "POST" }
      );
      if (!response.ok) {
        throw new Error("Failed to accept request.");
      }

      // Update state after acceptance
      const updatedRequests = requests.filter((req) => req._id !== requestId);
      const acceptedRequest = requests.find((req) => req._id === requestId);

      setRequests(updatedRequests);
      setAcceptedRequests([...acceptedRequests, acceptedRequest]);
    } catch (err) {
      console.error("Error accepting request:", err);
    }
  };

  return (
    <div className="volunteer-dashboard container py-5">
      <h2 className="text-center text-primary mb-4">Volunteer Dashboard</h2>
      <p className="text-center text-muted mb-5">
        View and accept requests from community members.
      </p>

      <div className="requests-section mb-5">
        <h3 className="text-secondary">Pending Requests</h3>
        {requests.length === 0 ? (
          <p className="text-muted">No pending requests.</p>
        ) : (
          <ul className="request-list">
            {requests.map((request) => (
              <li key={request._id} className="request-item">
                <div>
                  <strong>Task ID:</strong> {request.taskId}
                  <br />
                  <strong>Name:</strong> {request.name}
                  <br />
                  <strong>Email:</strong> {request.email}
                  <br />
                  <strong>Phone:</strong> {request.phone}
                  <br />
                  <strong>Date:</strong> {request.date}
                  <br />
                  <strong>Time:</strong> {request.time}
                </div>
                <button
                  className="btn btn-success"
                  onClick={() => handleAccept(request._id)}
                >
                  Accept
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="accepted-requests-section">
        <h3 className="text-secondary">Accepted Requests</h3>
        {acceptedRequests.length === 0 ? (
          <p className="text-muted">No accepted requests yet.</p>
        ) : (
          <ul className="accepted-list">
            {acceptedRequests.map((request) => (
              <li key={request._id} className="accepted-item">
                <div>
                  <strong>Task ID:</strong> {request.taskId}
                  <br />
                  <strong>Name:</strong> {request.name}
                  <br />
                  <strong>Date:</strong> {request.date}
                  <br />
                  <strong>Time:</strong> {request.time}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <Footer />
    </div>
  );
}

export default VolunteerDashboard;
