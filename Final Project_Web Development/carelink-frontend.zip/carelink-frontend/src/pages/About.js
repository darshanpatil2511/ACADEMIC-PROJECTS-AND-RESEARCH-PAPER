import React from "react";
import "../styles/About.css";
import Footer from "../components/Footer";

function About() {
  return (
    <div className="about-page">
      {/* About Section */}
      <section className="about py-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-6 mb-4 mb-lg-0">
              <img
                src="https://wpvip.edutopia.org/wp-content/uploads/2023/11/iStock-1721199068-crop.jpg?w=2880&quality=85"
                alt="Community Engagement"
                className="img-fluid rounded shadow-lg"
              />
            </div>
            <div className="col-lg-6">
              <h2 className="mb-3 text-primary">About CareLink Connect</h2>
              <p className="text-muted">
                At <strong>CareLink Connect</strong>, we believe in the power of
                community. Our mission is to foster meaningful connections
                between students and elderly members of society, bridging
                generational gaps and building a stronger, more inclusive
                community.
              </p>

              <div className="vision-values mt-4">
                <h5 className="text-primary">Our Vision</h5>
                <p className="text-muted">
                  To create a world where every individual feels valued,
                  supported, and connected, regardless of age or background.
                </p>

                <h5 className="text-primary mt-4">Our Values</h5>
                <ul className="list-unstyled">
                  <li className="mb-2">
                    <strong className="text-primary">Empathy:</strong>{" "}
                    Understanding and sharing the feelings of others.
                  </li>
                  <li className="mb-2">
                    <strong className="text-primary">Inclusion:</strong>{" "}
                    Embracing diversity and fostering mutual respect.
                  </li>
                  <li className="mb-2">
                    <strong className="text-primary">Community:</strong>{" "}
                    Building relationships that strengthen and uplift.
                  </li>
                  <li className="mb-2">
                    <strong className="text-primary">Growth:</strong>{" "}
                    Encouraging personal and collective development.
                  </li>
                </ul>
              </div>

              <a
                href="/signup"
                className="btn btn-primary btn-lg mt-4"
                aria-label="Join Us Today"
              >
                Join Us Today
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Section */}
      <section className="impact py-5 bg-light">
        <div className="container text-center">
          <h2 className="mb-4 text-primary">Our Impact</h2>
          <p className="text-muted mb-5">
            Together, we’ve helped connect thousands of students and seniors,
            creating bonds that have enriched lives and strengthened
            communities.
          </p>
          <div className="row">
            <div className="col-md-4 mb-4">
              <div className="card h-100 shadow rounded">
                <div className="card-body">
                  <h5 className="card-title text-primary">500+</h5>
                  <p className="card-text">
                    Students empowered to make a difference.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-md-4 mb-4">
              <div className="card h-100 shadow rounded">
                <div className="card-body">
                  <h5 className="card-title text-primary">1,000+</h5>
                  <p className="card-text">
                    Seniors supported with care and companionship.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-md-4 mb-4">
              <div className="card h-100 shadow rounded">
                <div className="card-body">
                  <h5 className="card-title text-primary">200+</h5>
                  <p className="card-text">
                    Community events and workshops conducted.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Meet the Team Section */}
      <section className="team py-5">
        <div className="container text-center">
          <h2 className="mb-4 text-primary">Meet Our Team</h2>
          <p className="text-muted mb-5">
            Our dedicated team of volunteers, coordinators, and leaders work
            tirelessly to build bridges and foster meaningful connections.
          </p>
          <div className="row">
            {[
              {
                name: "Darshan Patil",
                role: "Program Coordinator",
                image:
                  "https://via.placeholder.com/150",
              },
              {
                name: "Siddhant Pai",
                role: "Volunteer Leader",
                image:
                  "https://via.placeholder.com/150",
              },
              {
                name: "Gaurav Shukla",
                role: "Community Outreach",
                image:
                  "https://via.placeholder.com/150",
              },
              {
                name: "Soham Chavan",
                role: "Events Manager",
                image:
                  "https://via.placeholder.com/150",
              },
            ].map((member, index) => (
              <div className="col-md-3 mb-4" key={index}>
                <img
                  src={member.image}
                  alt={`${member.name}`}
                  className="img-fluid rounded-circle mb-2"
                />
                <h5 className="text-primary">{member.name}</h5>
                <p className="text-muted">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}

export default About;
