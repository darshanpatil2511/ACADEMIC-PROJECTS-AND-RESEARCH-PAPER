import React, { useState } from "react";
import "../styles/JoinVolunteer.css";
import Footer from "../components/Footer";

function JoinVolunteer() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    interests: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  // Handle form field changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const response = await fetch("http://localhost:5009/api/volunteers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Failed to submit application. Please try again.");
      }

      setSubmitted(true);

      // Clear form fields after submission
      setFormData({
        fullName: "",
        email: "",
        phone: "",
        interests: "",
      });

      // Automatically hide the success message after 3 seconds
      setTimeout(() => {
        setSubmitted(false);
      }, 3000);
    } catch (err) {
      console.error("Error submitting form:", err);
      setError(err.message);
    }
  };

  return (
    <div className="container py-5">
      <h1 className="text-primary mb-4">Join as a Volunteer</h1>
      <p className="text-muted">
        Thank you for your interest in joining CareLink Connect as a volunteer!
        Your time and dedication will make a meaningful impact on the lives of
        our community members.
      </p>

      {submitted && (
        <div className="alert alert-success" role="alert">
          Submitted Successfully!
        </div>
      )}

      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      )}

      <form className="mt-4" onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="fullName" className="form-label">
            Full Name
          </label>
          <input
            type="text"
            className="form-control"
            id="fullName"
            name="fullName"
            placeholder="Enter your full name"
            value={formData.fullName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">
            Email Address
          </label>
          <input
            type="email"
            className="form-control"
            id="email"
            name="email"
            placeholder="Enter your email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="phone" className="form-label">
            Phone Number
          </label>
          <input
            type="text"
            className="form-control"
            id="phone"
            name="phone"
            placeholder="Enter your phone number"
            value={formData.phone}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="interests" className="form-label">
            Areas of Interest
          </label>
          <textarea
            className="form-control"
            id="interests"
            name="interests"
            rows="4"
            placeholder="Describe your areas of interest and skills"
            value={formData.interests}
            onChange={handleChange}
            required
          ></textarea>
        </div>
        <button type="submit" className="btn btn-primary">
          Submit Application
        </button>
      </form>
      <Footer />
    </div>
  );
}

export default JoinVolunteer;
