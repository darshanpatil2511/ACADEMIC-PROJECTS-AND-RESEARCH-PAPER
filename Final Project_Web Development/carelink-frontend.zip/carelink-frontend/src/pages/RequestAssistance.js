import React, { useState } from "react";
import "../styles/RequestAssistance.css";
import Footer from "../components/Footer";

const tasks = [
  { id: 1, title: "Companionship Visit" },
  { id: 2, title: "Tech Assistance" },
  { id: 3, title: "Community Workshop" },
  { id: 4, title: "Grocery Assistance" },
  { id: 5, title: "Health Check Support" },
  { id: 6, title: "Gardening Help" },
];

function RequestAssistance() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    description: "",
    selectedTask: null,
    date: "",
    time: "",
  });

  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleTaskSelection = (taskId) => {
    setFormData({ ...formData, selectedTask: taskId });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!formData.selectedTask) {
      setError("Please select a task before submitting.");
      return;
    }

    try {
      const response = await fetch("http://localhost:5009/api/requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Failed to submit request.");
      }

      setSubmitted(true);

      // Reset form fields
      setFormData({
        name: "",
        email: "",
        phone: "",
        description: "",
        selectedTask: null,
        date: "",
        time: "",
      });
    } catch (err) {
      console.error("Error submitting request:", err);
      setError(err.message);
    }
  };

  return (
    <div className="request-assistance-page">
      <div className="container py-5">
        <h2 className="text-center text-primary mb-4">Request Assistance</h2>
        <p className="text-center text-muted mb-5">
          Please fill out the form below, and we’ll reach out to help you.
        </p>

        {submitted ? (
          <div className="alert alert-success text-center">
            Your request has been submitted successfully!
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="request-form">
            {error && (
              <div className="alert alert-danger text-center">{error}</div>
            )}

            <div className="mb-3">
              <label htmlFor="name" className="form-label">
                Name
              </label>
              <input
                type="text"
                className="form-control"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label htmlFor="email" className="form-label">
                Email
              </label>
              <input
                type="email"
                className="form-control"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label htmlFor="phone" className="form-label">
                Phone Number
              </label>
              <input
                type="tel"
                className="form-control"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Select a Task</label>
              <div className="task-list">
                {tasks.map((task) => (
                  <div key={task.id} className="task-item">
                    <input
                      type="radio"
                      id={`task-${task.id}`}
                      name="selectedTask"
                      checked={formData.selectedTask === task.id}
                      onChange={() => handleTaskSelection(task.id)}
                    />
                    <label htmlFor={`task-${task.id}`} className="task-label">
                      <strong>{task.title}</strong>
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <div className="mb-3">
              <label htmlFor="date" className="form-label">
                Date
              </label>
              <input
                type="date"
                className="form-control"
                id="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-4">
              <label htmlFor="time" className="form-label">
                Time
              </label>
              <input
                type="time"
                className="form-control"
                id="time"
                name="time"
                value={formData.time}
                onChange={handleChange}
                required
              />
            </div>

            <button type="submit" className="btn btn-primary w-100">
              Submit
            </button>
          </form>
        )}
      </div>

      <Footer />
    </div>
  );
}

export default RequestAssistance;
