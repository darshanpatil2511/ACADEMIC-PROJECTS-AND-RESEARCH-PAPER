import React from "react";
import "../styles/Home.css";
import Footer from "../components/Footer";

function Home() {
  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-overlay">
          <div className="container text-center text-white">
            <h1 className="display-4">CareLink Connect</h1>
            <p className="lead">Bridging Generations, Building Community</p>
            <a href="/signup" className="btn btn-primary btn-lg mx-2">
              Join as a Volunteer
            </a>
            <a
              href="/request-assistance"
              className="btn btn-secondary btn-lg mx-2"
              aria-label="Request Assistance"
            >
              Request Assistance
            </a>
          </div>
        </div>
      </section>

      {/* Carousel Section */}
      <section className="carousel-section py-5">
        <div
          id="carouselExample"
          className="carousel slide"
          data-bs-ride="carousel"
        >
          <div className="carousel-inner">
            <div className="carousel-item active">
              <img
                src="https://media.istockphoto.com/id/1473155461/photo/nurse-hands-and-senior-patient-in-empathy-safety-and-support-of-help-trust-and-healthcare.jpg?s=612x612&w=0&k=20&c=I5fh75AaVB0hVNE4-7JeY9g6sugFP4_4ZEQRPAPvJws="
                className="d-block w-100"
                alt="Community engagement"
              />
            </div>
            <div className="carousel-item">
              <img
                src="https://images.unsplash.com/photo-1593968983344-68c75b934b3c"
                className="d-block w-100"
                alt="Volunteers planting trees"
              />
            </div>
            <div className="carousel-item">
              <img
                src="https://images.unsplash.com/photo-1532635241-18a65e4f2c4c"
                className="d-block w-100"
                alt="Hands reaching out to help"
              />
            </div>
          </div>
          <button
            className="carousel-control-prev"
            type="button"
            data-bs-target="#carouselExample"
            data-bs-slide="prev"
          >
            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Previous</span>
          </button>
          <button
            className="carousel-control-next"
            type="button"
            data-bs-target="#carouselExample"
            data-bs-slide="next"
          >
            <span className="carousel-control-next-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </section>

      {/* Cards Section */}
      <section className="cards-section py-5">
        <div className="container">
          <div className="row">
            <div className="col-md-4 mb-4">
              <div className="card h-100 shadow">
                <img
                  src="http://hscnews.usc.edu/wp-content/uploads/2013/07/12-07-12_87364.jpg"
                  className="card-img-top"
                  alt="Students working together"
                />
                <div className="card-body">
                  <h5 className="card-title">Empower Students</h5>
                  <p className="card-text">
                    Help students make a positive impact in their communities.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-md-4 mb-4">
              <div className="card h-100 shadow">
                <img
                  src="https://www.griswoldcare.com/wp-content/uploads/2024/04/bigstock-Elderly-Woman-With-Female-Care-282707041.jpg"
                  className="card-img-top"
                  alt="Elderly person receiving support"
                />
                <div className="card-body">
                  <h5 className="card-title">Support Elders</h5>
                  <p className="card-text">
                    Provide companionship and care to elderly residents.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-md-4 mb-4">
              <div className="card h-100 shadow">
                <img
                  src="https://homecaregenerations.com/wp-content/uploads/AdobeStock_483013842.jpg"
                  className="card-img-top"
                  alt="Community members building connections"
                />
                <div className="card-body">
                  <h5 className="card-title">Build Community</h5>
                  <p className="card-text">
                    Foster connections that bridge generational gaps.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}

export default Home;
