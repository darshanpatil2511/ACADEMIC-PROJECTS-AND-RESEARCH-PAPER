import React, { useState, useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Login from "./components/Auth/Login";
import Signup from "./components/Auth/Signup";
import TaskList from "./components/Tasks/TaskList";
import TaskDetail from "./components/Tasks/TaskDetail";
import VolunteerDashboard from "./components/Dashboard/VolunteerDashboard";
import AdminDashboard from "./components/Dashboard/AdminDashboard";
import Payment from "./pages/Payment";
import JoinVolunteer from "./pages/JoinVolunteer";
import RequestAssistance from "./pages/RequestAssistance";

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState(null); // Tracks role ('Volunteer' or 'Admin')

  // Check for existing authentication status and role in localStorage on initial load
  useEffect(() => {
    const storedAuth = localStorage.getItem("isAuthenticated");
    const storedRole = localStorage.getItem("role");
    if (storedAuth === "true" && storedRole) {
      setIsAuthenticated(true);
      setUserRole(storedRole);
    }
  }, []);

  // Handle successful login/signup
  const handleAuthSuccess = (role) => {
    setIsAuthenticated(true);
    setUserRole(role);
    localStorage.setItem("isAuthenticated", "true");
    localStorage.setItem("role", role);
  };

  // Handle logout
  const handleLogout = () => {
    setIsAuthenticated(false);
    setUserRole(null);
    localStorage.removeItem("isAuthenticated");
    localStorage.removeItem("role");
    localStorage.removeItem("token");
  };

  return (
    <>
      <Navbar onLogout={handleLogout} isAuthenticated={isAuthenticated} />
      <Routes>
        {/* Public Routes Accessible to Everyone */}
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/join-volunteer" element={<JoinVolunteer />} />
        <Route path="/request-assistance" element={<RequestAssistance />} />

        {/* Unauthenticated Routes */}
        {!isAuthenticated && (
          <>
            <Route
              path="/login"
              element={<Login onLoginSuccess={handleAuthSuccess} />}
            />
            <Route
              path="/signup"
              element={<Signup onSignupSuccess={handleAuthSuccess} />}
            />
          </>
        )}

        {/* Authenticated Routes */}
        {isAuthenticated && (
          <>
            {/* Role-based Routing */}
            {userRole === "Volunteer" && (
              <>
                <Route path="/tasks" element={<TaskList />} />
                <Route path="/task/:id" element={<TaskDetail />} />
                <Route
                  path="/volunteer-dashboard"
                  element={<VolunteerDashboard />}
                />
              </>
            )}
            {userRole === "Admin" && (
              <Route path="/admin-dashboard" element={<AdminDashboard />} />
            )}
            <Route path="/payment" element={<Payment />} />
          </>
        )}

        {/* Fallback Redirect */}
        <Route
          path="*"
          element={
            <Navigate to={isAuthenticated ? "/" : "/login"} replace />
          }
        />
      </Routes>
    </>
  );
}

export default App;
