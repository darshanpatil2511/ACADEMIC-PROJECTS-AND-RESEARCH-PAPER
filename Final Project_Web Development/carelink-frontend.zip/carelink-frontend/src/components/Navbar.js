import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../styles/Navbar.css"; // Ensure this is the correct path to your CSS

function Navbar() {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Check if the user is authenticated on component mount
  useEffect(() => {
    const token = localStorage.getItem("token");
    setIsAuthenticated(!!token);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role"); // Clear role if stored
    localStorage.removeItem("userId"); // Clear userId if stored
    setIsAuthenticated(false);
    navigate("/login");
  };

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  return (
    <nav className="custom-navbar">
      <div className="navbar-container">
        <Link className="navbar-brand" to="/">
          CareLink Connect
        </Link>

        {/* Menu Toggle Button for Mobile */}
        <button className="menu-toggle" onClick={toggleMenu}>
          ☰
        </button>

        <div className={`navbar-links ${menuOpen ? "show" : ""}`}>
          <Link className="nav-link" to="/" onClick={() => setMenuOpen(false)}>
            Home
          </Link>
          <Link className="nav-link" to="/about" onClick={() => setMenuOpen(false)}>
            About
          </Link>
          <Link className="nav-link" to="/tasks" onClick={() => setMenuOpen(false)}>
            Tasks
          </Link>
          <Link className="nav-link" to="/contact" onClick={() => setMenuOpen(false)}>
            Contact
          </Link>
          <Link className="nav-link" to="/payment" onClick={() => setMenuOpen(false)}>
            Payment
          </Link>

          {/* Conditionally Render Buttons Based on Authentication */}
          {isAuthenticated ? (
            <button className="btn nav-link logout-btn" onClick={handleLogout}>
              Logout
            </button>
          ) : (
            <>
              <Link className="nav-link" to="/login" onClick={() => setMenuOpen(false)}>
                Login
              </Link>
              <Link className="nav-link" to="/signup" onClick={() => setMenuOpen(false)}>
                Signup
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
