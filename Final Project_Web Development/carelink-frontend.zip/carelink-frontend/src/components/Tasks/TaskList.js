import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Footer from "../Footer";
import { fetchTasks } from "../../services/api"; // API function to fetch tasks
import "../../styles/Task.css";

function TaskList() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const getTasks = async () => {
      try {
        const response = await fetchTasks(); // Fetch tasks from backend
        setTasks(response.data);
      } catch (err) {
        console.error("Error fetching tasks:", err);
        setError("Failed to load tasks. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    getTasks();
  }, []);

  if (loading) return <div className="container py-5 text-center">Loading...</div>;
  if (error) return <div className="container py-5 text-center text-danger">{error}</div>;

  return (
    <div className="task-list-page">
      {/* Header Section */}
      <section className="task-header py-5 bg-primary text-white text-center">
        <div className="container">
          <h1 className="display-4">Task List</h1>
          <p className="lead">
            Discover meaningful tasks that create a positive impact on the lives of our community members.
          </p>
        </div>
      </section>

      {/* Task Cards Section */}
      <div className="container py-5">
        <h2 className="text-center text-primary mb-4">Explore Available Tasks</h2>
        <p className="text-center task-description mb-5">
          Each task is an opportunity to connect, support, and uplift. Choose a task that aligns with your interests and availability.
        </p>
        <div className="row">
          {tasks.map((task) => {
            const requestData = localStorage.getItem(`task-request-${task._id}`);
            return (
              <div className="col-lg-4 mb-4" key={task._id}>
                <div className="card h-100 shadow rounded">
                  <div className="card-body d-flex flex-column">
                    <h5 className="card-title text-primary">{task.title}</h5>
                    <p className="text-muted flex-grow-1">{task.description}</p>
                    {requestData && (
                      <span className="badge bg-success mb-2">Request Generated</span>
                    )}
                    <Link to={`/task/${task._id}`} className="btn btn-primary btn-sm mt-auto">
                      View Details
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Summary Section */}
      <section className="task-summary py-5 bg-light text-center">
        <div className="container">
          <h2 className="text-primary mb-3">Make an Impact</h2>
          <p className="text-muted">
            Every small action contributes to a stronger, more connected community. Join us in making a difference today.
          </p>
          <Link to="/signup" className="btn btn-primary btn-lg mt-3" aria-label="Join as a Volunteer">
            Join as a Volunteer
          </Link>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}

export default TaskList;
