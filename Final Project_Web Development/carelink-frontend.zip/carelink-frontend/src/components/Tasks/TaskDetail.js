import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import Footer from "../Footer";
import { fetchTaskById, assignTaskToVolunteer } from "../../services/api";

function TaskDetail() {
  const { id } = useParams();
  const [task, setTask] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [requestData, setRequestData] = useState(null);

  useEffect(() => {
    const fetchTaskDetails = async () => {
      try {
        const response = await fetchTaskById(id);
        setTask(response.data);
        setRequestData(JSON.parse(localStorage.getItem(`task-request-${id}`)));
      } catch (err) {
        console.error("Error fetching task details:", err.message);
        setError("Failed to load task details.");
      } finally {
        setLoading(false);
      }
    };

    fetchTaskDetails();
  }, [id]);

  const handleAssignVolunteer = async () => {
    try {
      const volunteerId = localStorage.getItem("userId");
      if (!volunteerId) throw new Error("Volunteer not logged in.");

      await assignTaskToVolunteer(id, volunteerId);
      alert("Task successfully assigned to you!");
      setTask((prevTask) => ({
        ...prevTask,
        assignedTo: { id: volunteerId, name: "You" }, // Optimistic update
        status: "In Progress",
      }));
    } catch (err) {
      console.error("Error assigning volunteer:", err.message);
      alert("Failed to assign task. Please try again.");
    }
  };

  if (loading) return <div className="container py-5">Loading...</div>;
  if (error) return <div className="container py-5 text-danger">{error}</div>;

  return (
    <div className="container py-5">
      <div className="card shadow-lg p-4">
        <h2 className="text-primary mb-3">{task.name}</h2>
        <p className="text-muted mb-4">{task.description}</p>

        {requestData ? (
          <>
            <hr />
            <h4 className="text-secondary">Request Details</h4>
            <p><strong>Name:</strong> {requestData.name}</p>
            <p><strong>Email:</strong> {requestData.email}</p>
            <p><strong>Phone:</strong> {requestData.phone}</p>
            <p><strong>Date:</strong> {requestData.date}</p>
            <p><strong>Time:</strong> {requestData.time}</p>
            {task.assignedTo ? (
              <p className="text-success mt-3">
                <strong>Assigned To:</strong> {task.assignedTo.name}
              </p>
            ) : (
              <button
                className="btn btn-success mt-4"
                onClick={handleAssignVolunteer}
              >
                Accept Request
              </button>
            )}
          </>
        ) : (
          <p className="text-muted">
            No requests have been made for this task yet.
          </p>
        )}

        <Link to="/tasks" className="btn btn-primary mt-4">
          Back to Task List
        </Link>
      </div>
      <Footer />
    </div>
  );
}

export default TaskDetail;
