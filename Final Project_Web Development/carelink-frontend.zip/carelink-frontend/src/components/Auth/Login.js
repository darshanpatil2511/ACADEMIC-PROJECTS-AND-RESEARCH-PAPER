import React, { useState } from "react";
import "../../styles/Login.css"; // Ensure the correct path for your CSS file

const Login = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Make the login API call
      const response = await fetch("http://localhost:5009/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }), // Send login credentials
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Login failed. Please check your credentials.");
      }

      const data = await response.json();

      // Save the token and role in localStorage for authentication and redirection
      localStorage.setItem("token", data.token);
      localStorage.setItem("role", data.role);

      // Role-based redirection
      if (data.role === "customer") {
        window.location.href = "/request-assistance";
      } else if (data.role === "volunteer") {
        window.location.href = "/tasks";
      }

      // Trigger the success callback if provided
      if (onLoginSuccess) {
        onLoginSuccess();
      }
    } catch (err) {
      // Set the error message if login fails
      setError(err.message || "An unexpected error occurred.");
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h2>Login</h2>
        {error && <div className="error-message">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              required
            />
          </div>
          <button type="submit" className="login-button">
            Login
          </button>
        </form>
        <button
          className="signup-button"
          onClick={() => (window.location.href = "/signup")}
        >
          Sign up
        </button>
      </div>
    </div>
  );
};

export default Login;
