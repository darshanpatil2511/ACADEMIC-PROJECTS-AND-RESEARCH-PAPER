import React, { useState, useEffect } from "react";
import { fetchTasks, fetchVolunteers } from "../../services/api"; // Import API functions

function AdminDashboard() {
  const [tasks, setTasks] = useState([]);
  const [volunteers, setVolunteers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const getData = async () => {
      try {
        const tasksResponse = await fetchTasks();
        const volunteersResponse = await fetchVolunteers();
        setTasks(tasksResponse.data);
        setVolunteers(volunteersResponse.data);
      } catch (err) {
        console.error("Error fetching data:", err);
        setError("Failed to load dashboard data.");
      } finally {
        setLoading(false);
      }
    };

    getData();
  }, []);

  if (loading) return <div className="container mt-5">Loading...</div>;
  if (error) return <div className="container mt-5 text-danger">{error}</div>;

  return (
    <div className="container mt-5">
      <header>
        <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
          <div className="container-fluid">
            <a className="navbar-brand" href="#">Admin Dashboard</a>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <a className="nav-link active" href="#">
                    Dashboard
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Manage Tasks
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Manage Volunteers
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </header>

      <section className="dashboard py-5">
        <h2 className="mb-4">Admin Overview</h2>
        <div className="row">
          <div className="col-md-4">
            <div className="card text-center shadow-sm">
              <div className="card-body">
                <h5 className="card-title">Total Tasks</h5>
                <p className="card-text display-4">{tasks.length}</p>
              </div>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card text-center shadow-sm">
              <div className="card-body">
                <h5 className="card-title">Active Volunteers</h5>
                <p className="card-text display-4">{volunteers.length}</p>
              </div>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card text-center shadow-sm">
              <div className="card-body">
                <h5 className="card-title">Completed Tasks</h5>
                <p className="card-text display-4">
                  {tasks.filter((task) => task.status === "Completed").length}
                </p>
              </div>
            </div>
          </div>
        </div>

        <h3 className="mt-5">Manage Tasks</h3>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>Task Name</th>
              <th>Status</th>
              <th>Assigned To</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((task, index) => (
              <tr key={task._id}>
                <td>{index + 1}</td>
                <td>{task.name}</td>
                <td>
                  <span
                    className={`badge ${
                      task.status === "Completed"
                        ? "bg-success"
                        : task.status === "In Progress"
                        ? "bg-warning"
                        : "bg-primary"
                    }`}
                  >
                    {task.status}
                  </span>
                </td>
                <td>
                  {task.assignedTo ? task.assignedTo.name : "Unassigned"}
                </td>
                <td>
                  <button
                    className="btn btn-primary btn-sm me-2"
                    onClick={() => handleEdit(task)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleDelete(task._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <footer className="text-center py-4">
        <p>&copy; 2024 CareLink Connect. All Rights Reserved.</p>
      </footer>
    </div>
  );
}

// Placeholder functions for editing and deleting tasks
const handleEdit = (task) => {
  console.log("Edit Task:", task);
};

const handleDelete = async (taskId) => {
  try {
    const response = await fetch(`http://localhost:5009/api/tasks/${taskId}`, {
      method: "DELETE",
    });

    if (!response.ok) {
      throw new Error("Failed to delete task.");
    }

    alert("Task deleted successfully!");
    window.location.reload(); // Reload the page to reflect changes
  } catch (err) {
    console.error("Delete Error:", err.message);
    alert("Error deleting task. Please try again.");
  }
};

export default AdminDashboard;
