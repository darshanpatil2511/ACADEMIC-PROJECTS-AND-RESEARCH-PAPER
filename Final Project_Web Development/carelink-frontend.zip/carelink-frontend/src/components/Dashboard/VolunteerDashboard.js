import React, { useState, useEffect } from "react";
import { fetchTasks } from "../../services/api"; // Import API function

function VolunteerDashboard() {
  const [tasks, setTasks] = useState([]);
  const [completedTasks, setCompletedTasks] = useState(0);
  const [activeTasks, setActiveTasks] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [volunteerName, setVolunteerName] = useState("Volunteer");

  useEffect(() => {
    const getTasks = async () => {
      try {
        const userId = localStorage.getItem("userId");
        const volunteerName = localStorage.getItem("userName");
        setVolunteerName(volunteerName || "Volunteer");

        const response = await fetchTasks(); // Fetch all tasks
        const volunteerTasks = response.data.filter(
          (task) => task.assignedTo && task.assignedTo.id === userId
        );

        setTasks(volunteerTasks);
        setCompletedTasks(
          volunteerTasks.filter((task) => task.status === "Completed").length
        );
        setActiveTasks(
          volunteerTasks.filter((task) => task.status === "In Progress").length
        );
      } catch (err) {
        console.error("Error fetching tasks:", err);
        setError("Failed to load dashboard data.");
      } finally {
        setLoading(false);
      }
    };

    getTasks();
  }, []);

  if (loading) return <div className="container mt-5">Loading...</div>;
  if (error) return <div className="container mt-5 text-danger">{error}</div>;

  return (
    <div className="container mt-5">
      <header>
        <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
          <div className="container-fluid">
            <a className="navbar-brand" href="#">Volunteer Dashboard</a>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <a className="nav-link active" href="#">
                    Dashboard
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Assigned Tasks
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Profile
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </header>

      <section className="dashboard py-5">
        <h2 className="mb-4">Welcome, {volunteerName}</h2>
        <div className="row">
          <div className="col-md-4">
            <div className="card text-center shadow-sm">
              <div className="card-body">
                <h5 className="card-title">Tasks Completed</h5>
                <p className="card-text display-4">{completedTasks}</p>
              </div>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card text-center shadow-sm">
              <div className="card-body">
                <h5 className="card-title">Hours Volunteered</h5>
                <p className="card-text display-4">{completedTasks * 2}</p> {/* Assumes 2 hours per task */}
              </div>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card text-center shadow-sm">
              <div className="card-body">
                <h5 className="card-title">Active Tasks</h5>
                <p className="card-text display-4">{activeTasks}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="text-center py-4">
        <p>&copy; 2024 CareLink Connect. All Rights Reserved.</p>
      </footer>
    </div>
  );
}

export default VolunteerDashboard;
