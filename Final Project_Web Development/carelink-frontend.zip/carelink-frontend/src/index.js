import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { BrowserRouter } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap CSS
import axios from "axios";

// Set the base URL for Axios globally
axios.defaults.baseURL = "http://localhost:5009/api"; // Adjust based on your backend setup
axios.defaults.headers.common["Content-Type"] = "application/json";

// Include the Authorization token in every Axios request
axios.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);

// Uncomment and customize the line below to use reportWebVitals for performance monitoring
// import reportWebVitals from './reportWebVitals';
// reportWebVitals(console.log);
