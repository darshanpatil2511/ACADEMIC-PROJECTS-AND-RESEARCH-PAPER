import axios from "axios";

const API_BASE_URL = "http://localhost:5009/api"; // Ensure backend URL is correct

// Set up Axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Interceptor to include token in requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Interceptor to handle errors globally
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      // Server-side error
      console.error("API Error:", error.response.data);
      return Promise.reject(error.response.data); // Pass error data
    } else {
      // Network error
      console.error("Network Error:", error.message);
      return Promise.reject({ error: "Network error. Please try again later." });
    }
  }
);

// Authentication APIs
export const login = async (credentials) => {
  try {
    const response = await api.post("/auth/login", credentials);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const signup = async ({ name, email, password, role }) => {
  try {
    const response = await api.post("/auth/signup", {
      name,
      email,
      password,
      role,
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Task APIs
export const fetchTasks = async () => {
  try {
    const response = await api.get("/tasks");
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const fetchTaskById = async (id) => {
  try {
    const response = await api.get(`/tasks/${id}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createTask = async (taskData) => {
  try {
    const response = await api.post("/tasks", taskData);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const updateTask = async (id, updates) => {
  try {
    const response = await api.put(`/tasks/${id}`, updates);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const deleteTask = async (id) => {
  try {
    const response = await api.delete(`/tasks/${id}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Assign a task to a volunteer
export const assignTaskToVolunteer = async (taskId, volunteerId) => {
  try {
    const response = await api.put(`/tasks/${taskId}/assign`, { volunteerId });
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Volunteer APIs
export const fetchVolunteers = async () => {
  try {
    const response = await api.get("/volunteers");
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const fetchVolunteerById = async (id) => {
  try {
    const response = await api.get(`/volunteers/${id}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const updateVolunteer = async (id, updates) => {
  try {
    const response = await api.put(`/volunteers/${id}`, updates);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const deleteVolunteer = async (id) => {
  try {
    const response = await api.delete(`/volunteers/${id}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Request APIs
export const fetchRequests = async () => {
  try {
    const response = await api.get("/requests");
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const fetchRequestById = async (id) => {
  try {
    const response = await api.get(`/requests/${id}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const acceptRequest = async (id) => {
  try {
    const response = await api.post(`/requests/${id}/accept`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createRequest = async (requestData) => {
  try {
    const response = await api.post("/requests", requestData);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Payment APIs
export const createPaymentIntent = async (amount, currency = "usd") => {
  try {
    const response = await api.post("/payments/create-payment-intent", {
      amount,
      currency,
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Export all functions for usage
export default {
  login,
  signup,
  fetchTasks,
  fetchTaskById,
  createTask,
  updateTask,
  deleteTask,
  assignTaskToVolunteer,
  fetchVolunteers,
  fetchVolunteerById,
  updateVolunteer,
  deleteVolunteer,
  fetchRequests,
  fetchRequestById,
  acceptRequest,
  createRequest,
  createPaymentIntent,
};
